{
  if (typeof window.RTCDataChannel !== "undefined") window.RTCDataChannel = undefined;
  if (typeof window.RTCIceCandidate !== "undefined") window.RTCIceCandidate = undefined;
  if (typeof window.RTCConfiguration !== "undefined") window.RTCConfiguration = undefined;
}
